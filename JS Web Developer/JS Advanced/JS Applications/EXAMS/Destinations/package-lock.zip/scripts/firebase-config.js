// Your web app's Firebase configuration
var firebaseConfig = {
  apiKey: "AIzaSyDS19ItIyLss8_8MM8c-FJo6TGXc7bDd24",
  authDomain: "exams-7e189.firebaseapp.com",
  projectId: "exams-7e189",
  storageBucket: "exams-7e189.appspot.com",
  messagingSenderId: "554772088223",
  appId: "1:554772088223:web:489908e8065bcff88369aa"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
