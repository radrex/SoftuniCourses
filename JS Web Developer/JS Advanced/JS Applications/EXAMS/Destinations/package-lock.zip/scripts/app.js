const app = Sammy('#container', function() {
  this.use('Handlebars', 'hbs'); // Specify Template Engine and its extension so it can compile

  //--------------------- HOME ---------------------
  this.get('/home', function(context) {
    const auth = localStorage.getItem('auth');
    if (auth) { // Check if logged through localStorage
      const { uid, email } = JSON.parse(auth);
      context.isLoggedIn = true; 
      context.email = email;
      context.destinations = [];

      firebase.firestore().collection("destinations").get().then(res => {
        res.forEach(doc => context.destinations.push({id: doc.id, ...doc.data()}));

        this.loadPartials({ // Do it only when our template contains partials
          'nav': '../templates/common/nav.hbs',
          'footer': '../templates/common/footer.hbs',
          'destinationCard': '../templates/home/destinationCard.hbs',
        })
        .then(function() {
          this.partial('../templates/home/home.hbs'); // After partials have been loaded, load the main template
        });
      });
    } else {
      this.loadPartials({ // Do it only when our template contains partials
        'nav': '../templates/common/nav.hbs',
        'footer': '../templates/common/footer.hbs',
        'destinationCard': '../templates/home/destinationCard.hbs',
      })
      .then(function() {
        this.partial('../templates/home/home.hbs'); // After partials have been loaded, load the main template
      });
    }
  });
  //-------------------- REGISTER ------------------
  this.get('/register', function() {
    this.loadPartials({
      'nav': '../templates/common/nav.hbs',
      'footer': '../templates/common/footer.hbs',
    })
    .then(function() {
      this.partial('../templates/register/register.hbs');
    });
  });
  this.post('/register', function(context) {
    const { email, password, rePassword } = context.params;

    let regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (!regex.test(email) || password === '' || password !== rePassword) {
      let errorNotification = document.querySelector('.notification.errorBox');
      errorNotification.textContent = "Invalid email or password";
      errorNotification.style.display = 'block';

      setTimeout(function() {
        errorNotification.style.display = 'none';
      }, 1500);
    } else {
      firebase.auth().createUserWithEmailAndPassword(email, password)
      .then(user => {
        const { user: { uid, email } } = user;
        localStorage.setItem('auth', JSON.stringify({ uid, email }));
        this.redirect('/home');
      })
      .then(x => {
        let infoNotification = document.querySelector('.notification.infoBox');
        infoNotification.textContent = "User registration successful.";
        infoNotification.style.display = 'block';
        setTimeout(function() {
          infoNotification.style.display = 'none';
        }, 1500);
      })
      .catch(err => console.log(err));
    }
  });

  //-------------------- LOGIN ---------------------
  this.get('/login', function() {
    this.loadPartials({
      'nav': '../templates/common/nav.hbs',
      'footer': '../templates/common/footer.hbs',
    })
    .then(function() {
      this.partial('../templates/login/login.hbs');
    });
  });
  this.post('/login', function(context) {
    const { email, password } = context.params;

    let regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (!regex.test(email) || password === '') {
      let errorNotification = document.querySelector('.notification.errorBox');
      errorNotification.textContent = "Invalid email or password";
      errorNotification.style.display = 'block';

      setTimeout(function() {
        errorNotification.style.display = 'none';
      }, 1500);
    } else {
      firebase.auth().signInWithEmailAndPassword(email, password)
      .then(user => {
        const { user: { uid, email } } = user;
        localStorage.setItem('auth', JSON.stringify({ uid, email }));
        this.redirect('/home');
      })
      .then(x => {
        let infoNotification = document.querySelector('.notification.infoBox');
        infoNotification.textContent = "Login successful.";
        infoNotification.style.display = 'block';
        setTimeout(function() {
          infoNotification.style.display = 'none';
        }, 1500);
      })
      .catch(err => console.log(err));
    }
  });

  //-------------------- LOGOUT --------------------
  this.get('/logout', function(context) {
    firebase.auth().signOut()
      .then(x => {
        localStorage.removeItem('auth');
        context.redirect('/login');
      })
      .then(x => {
        let infoNotification = document.querySelector('.notification.infoBox');
        infoNotification.textContent = "Logout successful.";
        infoNotification.style.display = 'block';
        setTimeout(function() {
          infoNotification.style.display = 'none';
        }, 1500);
      })
      .catch(err => console.log(err));
  });

  //-------------------- CREATE --------------------
  this.get('/create', function(context) {
    const auth = localStorage.getItem('auth');
    if (auth) {
      const { uid, email } = JSON.parse(auth);
      context.isLoggedIn = true; 
      context.email = email;

      this.loadPartials({
        'nav': '../templates/common/nav.hbs',
        'footer': '../templates/common/footer.hbs',
      })
      .then(function() {
        this.partial('../templates/destinations/create.hbs');
      });
    } else {
      this.loadPartials({
        'nav': '../templates/common/nav.hbs',
        'footer': '../templates/common/footer.hbs',
      })
      .then(function() {
        this.partial('../templates/destinations/create.hbs');
      });
    }
  });

  this.post('/create', function(context) {
    const { destination, city, duration, departureDate, imgUrl } = context.params;

    if (destination  === '' || city  === '' || duration  === '' || departureDate  === '' || imgUrl === '') {
      let errorNotification = document.querySelector('.notification.errorBox');
      errorNotification.textContent = "Please fill correct data";
      errorNotification.style.display = 'block';

      setTimeout(function() {
        errorNotification.style.display = 'none';
      }, 1500);
    } else {
      firebase.firestore().collection('destinations').add({
        destination, city, duration, departureDate, imgUrl,
        creator: JSON.parse(localStorage.getItem('auth')).email
      })
      .then(x => {
        this.redirect('/home');
      })
      .then(x => {
        let infoNotification = document.querySelector('.notification.infoBox');
        infoNotification.textContent = "Destination created successfully.";
        infoNotification.style.display = 'block';
        setTimeout(function() {
          infoNotification.style.display = 'none';
        }, 1500);
      })
      .catch(err => console.log(err));
    }
  });

  //-------------------- DETAILS -------------------
  this.get('/details/:id', function(context) {
    firebase.firestore().collection('destinations').doc(context.params.id).get().then(res => {
      const auth = localStorage.getItem('auth');  
      if (auth) { // Check if logged through localStorage
        const { uid, email } = JSON.parse(auth);
        context.isLoggedIn = true; 
        context.email = email;
        context.id = context.params.id;
        context.destinationData = res.data();
        context.isCreator = email === context.destinationData.creator;

        let depDate = res.data().departureDate.split('-');
        const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        context.departureDate = `${depDate[2]} ${months[+depDate[1]-1]} ${depDate[0]}`;
      }

      this.loadPartials({
        'nav': '../templates/common/nav.hbs',
        'footer': '../templates/common/footer.hbs',
      })
      .then(function() {
        this.partial('../templates/destinations/details.hbs');
      });
    });
  });

  //-------------------- EDIT ----------------------
  this.get('/edit/:id', function(context) {
    firebase.firestore().collection('destinations').doc(context.params.id).get().then(res => {
      const auth = localStorage.getItem('auth');  
      if (auth) { // Check if logged through localStorage
        const { uid, email } = JSON.parse(auth);
        context.isLoggedIn = true; 
        context.email = email;
        context.id = context.params.id;
        context.destinationData = res.data();
      }

      this.loadPartials({
        'nav': '../templates/common/nav.hbs',
        'footer': '../templates/common/footer.hbs',
      })
      .then(function() {
        this.partial('../templates/destinations/edit.hbs');
      });
    });
  });

  this.post('/edit/:id', function(context) {
    const { id, destination, city, duration, departureDate, imgUrl } = context.params;
    if (destination  === '' || city  === '' || duration  === '' || departureDate  === '' || imgUrl === '') {
      let errorNotification = document.querySelector('.notification.errorBox');
      errorNotification.textContent = "Please fill correct data";
      errorNotification.style.display = 'block';

      setTimeout(function() {
        errorNotification.style.display = 'none';
      }, 1500);
    } else {
      firebase.firestore().collection('destinations').doc(context.params.id).set({
        destination, city, duration, departureDate, imgUrl
      }, { merge: true }).then(x => {
        this.redirect(`/details/${id}`);
      })
      .then(x => {
        let infoNotification = document.querySelector('.notification.infoBox');
        infoNotification.textContent = "Successfully edited destination.";
        infoNotification.style.display = 'block';
        setTimeout(function() {
          infoNotification.style.display = 'none';
        }, 1500)
      })
      .catch(err => console.log(err));
    }
  });

  //---------------- MY DESTINATIONS ---------------
  this.get('/destinations', function(context) {
    const auth = localStorage.getItem('auth');
    if (auth) {
      context.destinations = [];
      firebase.firestore().collection("destinations").get().then(res => {
        const auth = localStorage.getItem('auth');
        const { uid, email } = JSON.parse(auth);
        context.isLoggedIn = true; 
        context.email = email;
  
        res.forEach(doc => {
          let obj = {id: doc.id, ...doc.data()};
          if (obj.creator === email) {
            context.destinations.push(obj);
          }
        });
  
        this.loadPartials({
          'nav': '../templates/common/nav.hbs',
          'footer': '../templates/common/footer.hbs',
          'destinationTicket': '../templates/destinations/destinationTicket.hbs',
        })
        .then(function() {
          this.partial('../templates/destinations/destinations.hbs');
        });
      });
    } else {
      this.loadPartials({
        'nav': '../templates/common/nav.hbs',
        'footer': '../templates/common/footer.hbs',
        'destinationTicket': '../templates/destinations/destinationTicket.hbs',
      })
      .then(function() {
        this.partial('../templates/destinations/destinations.hbs');
      });
    }
  });

  //-------------------- DELETE --------------------
  this.get('/delete/:id', function(context) {
    firebase.firestore().collection('destinations').doc(context.params.id).delete().then(res => {
      this.redirect('/destinations');
    })
    .then(x => {
      let infoNotification = document.querySelector('.notification.infoBox');
        infoNotification.textContent = "Destination deleted.";
        infoNotification.style.display = 'block';
        setTimeout(function() {
          infoNotification.style.display = 'none';
        }, 1500);
    })
    .catch(err => console.log(err));
  });

  //------------------------------------------------
});

(() => {  // Initial template load (first, when page loads)
  app.run('/home');
})();