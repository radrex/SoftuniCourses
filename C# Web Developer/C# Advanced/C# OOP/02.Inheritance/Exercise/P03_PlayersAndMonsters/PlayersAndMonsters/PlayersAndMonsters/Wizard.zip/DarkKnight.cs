﻿namespace PlayersAndMonsters
{
    public class DarkKnight : Knight
    {
        //---------------- Constructors ------------------
        public DarkKnight(string username, int level) : base(username, level)
        {

        }
    }
}
