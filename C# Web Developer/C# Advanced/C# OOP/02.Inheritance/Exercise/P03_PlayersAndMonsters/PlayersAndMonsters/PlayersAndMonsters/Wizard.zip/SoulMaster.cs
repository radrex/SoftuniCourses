﻿namespace PlayersAndMonsters
{
    public class SoulMaster : DarkWizard
    {
        //---------------- Constructors ------------------
        public SoulMaster(string username, int level) : base(username, level)
        {

        }
    }
}
